document.addEventListener('DOMContentLoaded', function() {
    alert('Сайт загружен!');
});
